Assignment 1 - Charis Aletraris

Report: Assignment1_Charis_Aletraris_Report.docx
Code: exercise1a.py to exercise1e.py and exercise2.py
plots/: saved accuracy figures
results/: saved summaries and per-run accuracy arrays where available

Environment: Python 3.12, TensorFlow/Keras, NumPy, scikit-learn and Matplotlib.
Install dependencies with: python -m pip install -r requirements.txt
requirements-lock.txt records the original environment versions.

Extract the ZIP before running. Open a terminal in this folder and run, for example:
python exercise1a.py
python exercise2.py

Each script runs independently. Exercise 1 uses 20 runs of 40 epochs per
configuration. Exercise 2 uses 20 runs of 40 epochs for the selected model.
Plots open after training; close their windows to finish the script.
Running scripts produces new plots/results. Saved outputs are included separately.
